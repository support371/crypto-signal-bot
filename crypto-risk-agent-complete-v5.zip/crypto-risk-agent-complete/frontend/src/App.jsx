import { useEffect, useMemo, useRef, useState } from 'react'
import { Area, AreaChart, ResponsiveContainer } from 'recharts'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'
const WS_BASE = import.meta.env.VITE_WS_BASE || 'ws://localhost:8000'

const C = {
  bg: '#080810', surface: '#0f0f1a', card: '#13131f', border: '#1e1e35',
  pink: '#f0176f', purple: '#7c3aed', green: '#22d3a5', orange: '#f97316',
  yellow: '#f59e0b', red: '#f87171', text: '#f1f0ff', muted: '#6b6a8f',
}

async function getJson(path, signal) {
  const res = await fetch(`${API_BASE}${path}`, { signal })
  if (!res.ok) throw new Error(`API ${res.status}`)
  return await res.json()
}

function usePolling(path, interval = 5000, initial = null) {
  const [data, setData] = useState(initial)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    let timer = null
    const load = async () => {
      const ctrl = new AbortController()
      try {
        const json = await getJson(path, ctrl.signal)
        if (alive) {
          setData(json)
          setError(null)
          setLoading(false)
        }
      } catch (err) {
        if (alive) {
          setError(err.message)
          setLoading(false)
        }
      }
      return () => ctrl.abort()
    }

    load()
    timer = setInterval(load, interval)
    return () => {
      alive = false
      clearInterval(timer)
    }
  }, [path, interval])

  return { data, error, loading }
}

function useEngineUpdates() {
  const [lastMessage, setLastMessage] = useState(null)
  const [status, setStatus] = useState('connecting')
  const retries = useRef(0)

  useEffect(() => {
    let ws = null
    let cancelled = false
    let reconnectTimer = null

    const connect = () => {
      if (cancelled) return
      setStatus('connecting')
      ws = new WebSocket(`${WS_BASE}/ws/updates`)
      ws.onopen = () => {
        retries.current = 0
        setStatus('connected')
        ws.send('subscribe')
      }
      ws.onmessage = (event) => {
        try {
          setLastMessage(JSON.parse(event.data))
        } catch {
          // ignore malformed frame
        }
      }
      ws.onerror = () => setStatus('degraded')
      ws.onclose = () => {
        if (cancelled) return
        setStatus('reconnecting')
        const delay = Math.min(1000 * (2 ** retries.current), 10000)
        retries.current += 1
        reconnectTimer = setTimeout(connect, delay)
      }
    }

    connect()
    return () => {
      cancelled = true
      clearTimeout(reconnectTimer)
      if (ws) ws.close()
    }
  }, [])

  return { lastMessage, status }
}

function Card({ title, value, sub, accent = C.purple, children }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 16 }}>
      <div style={{ color: C.muted, fontSize: 11, letterSpacing: 1, marginBottom: 8 }}>{title}</div>
      <div style={{ color: accent, fontSize: 28, fontWeight: 900 }}>{value}</div>
      {sub ? <div style={{ color: C.text, fontSize: 12, marginTop: 4 }}>{sub}</div> : null}
      {children}
    </div>
  )
}

function StatusPill({ label, value, tone }) {
  return (
    <div style={{ border: `1px solid ${C.border}`, borderRadius: 999, padding: '6px 10px', color: tone }}>
      <span style={{ color: C.muted, marginRight: 6 }}>{label}</span>{value}
    </div>
  )
}

export default function App() {
  const { data: health } = usePolling('/health', 4000, {})
  const { data: balances } = usePolling('/balance', 5000, { balances: [], total_usdt_equivalent: 0 })
  const { data: pnl } = usePolling('/pnl', 4000, { realized: 0, unrealized: 0, daily: 0, total_capital: 0, by_exchange: {} })
  const { data: positions } = usePolling('/positions', 5000, [])
  const { data: audit } = usePolling('/audit', 5000, [])
  const { data: guardian } = usePolling('/guardian/status', 4000, {})
  const { data: signal } = usePolling('/signal/latest', 4000, {})
  const { data: exchangeStatus } = usePolling('/exchange/status', 4000, {})
  const { data: reconciliation } = usePolling('/reconciliation/status', 7000, { latest_runtime: {}, history: [] })
  const { lastMessage: update, status: wsStatus } = useEngineUpdates()

  const chartData = useMemo(() => {
    const base = Object.entries(signal?.exchange_prices || {})
    return base.map(([exchange, price]) => ({ exchange, price }))
  }, [signal])

  const openPositions = positions.filter((p) => p.status === 'open')

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@700;800;900&display=swap');
        *{box-sizing:border-box} body{margin:0;background:${C.bg};font-family:'Syne',sans-serif;color:${C.text}}
        .grid{display:grid;gap:12px} .mono{font-family:'Space Mono', monospace}
      `}</style>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, gap: 16, flexWrap: 'wrap' }}>
          <div>
            <div style={{ color: C.text, fontWeight: 900, fontSize: 28 }}>Crypto Risk Agent</div>
            <div style={{ color: C.muted, fontSize: 12 }}>Autonomous risk-first trading console</div>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <StatusPill label="Engine" value={health?.kill_switch_active ? 'HALTED' : 'ACTIVE'} tone={health?.kill_switch_active ? C.red : C.green} />
            <StatusPill label="Mode" value={health?.trading_mode || 'paper'} tone={C.purple} />
            <StatusPill label="WS" value={wsStatus} tone={wsStatus === 'connected' ? C.green : C.orange} />
          </div>
        </div>

        {health?.kill_switch_active ? (
          <div style={{ background: 'rgba(248,113,113,0.12)', border: `1px solid ${C.red}`, borderRadius: 14, padding: 12, marginBottom: 16 }}>
            Guardian halt is active. Review reconciliation, positions, and audit before resuming operations.
          </div>
        ) : null}

        <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
          <Card title="TOTAL CAPITAL" value={`$${Number(pnl?.total_capital || 0).toLocaleString()}`} accent={C.green} sub="Ground-truth portfolio view" />
          <Card title="DAILY P&L" value={`$${Number(pnl?.daily || 0).toFixed(2)}`} accent={pnl?.daily >= 0 ? C.green : C.red} sub="Realized + unrealized" />
          <Card title="SIGNAL" value={signal?.direction || 'NEUTRAL'} accent={signal?.direction === 'DOWN' ? C.red : C.purple} sub={`Confidence ${(((signal?.confidence || 0) * 100)).toFixed(1)}%`} />
          <Card title="GUARDIAN" value={guardian?.state || 'ACTIVE'} accent={guardian?.state === 'HALTED' ? C.red : C.orange} sub={guardian?.last_trigger_reason || 'No active trigger'} />
        </div>

        <div className="grid" style={{ gridTemplateColumns: '1.45fr 1fr', alignItems: 'start' }}>
          <div className="grid">
            <Card title="CROSS-EXCHANGE PRICE MAP" value={signal?.regime || 'RANGE'} sub="Live normalized exchange prices">
              <div style={{ height: 240, marginTop: 12 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs><linearGradient id="price" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={C.pink} stopOpacity={0.45}/><stop offset="100%" stopColor={C.pink} stopOpacity={0.02}/></linearGradient></defs>
                    <Area dataKey="price" stroke={C.pink} fill="url(#price)" strokeWidth={3} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                {Object.entries(signal?.exchange_prices || {}).map(([exchange, price]) => (
                  <div key={exchange} style={{ border: `1px solid ${C.border}`, borderRadius: 12, padding: 10 }}>
                    <div style={{ color: C.muted, fontSize: 10 }}>{exchange.toUpperCase()}</div>
                    <div className="mono" style={{ fontWeight: 700 }}>${Number(price).toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </Card>

            <Card title="OPEN POSITIONS" value={String(openPositions.length)} sub="Execution engine state">
              <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
                {positions.length === 0 ? <div style={{ color: C.muted }}>No positions yet.</div> : positions.slice(0, 8).map((p) => (
                  <div key={p.id} style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr 0.9fr 0.8fr 0.8fr', gap: 8, padding: 10, border: `1px solid ${C.border}`, borderRadius: 12 }}>
                    <div><div style={{ color: C.muted, fontSize: 10 }}>{p.exchange.toUpperCase()}</div><div>{p.side.toUpperCase()} {p.symbol}</div></div>
                    <div><div style={{ color: C.muted, fontSize: 10 }}>Size</div><div className="mono">${Number(p.size_usdt).toFixed(2)}</div></div>
                    <div><div style={{ color: C.muted, fontSize: 10 }}>Entry</div><div className="mono">${Number(p.entry_price).toFixed(2)}</div></div>
                    <div><div style={{ color: C.muted, fontSize: 10 }}>PnL</div><div style={{ color: p.unrealized_pnl >= 0 ? C.green : C.red }}>${Number(p.unrealized_pnl).toFixed(2)}</div></div>
                    <div><div style={{ color: C.muted, fontSize: 10 }}>Status</div><div>{p.status}</div></div>
                  </div>
                ))}
              </div>
            </Card>

            <Card title="EXCHANGE STREAM HEALTH" value={String(Object.keys(exchangeStatus || {}).length)} sub="Connectivity, stream freshness, and balances">
              <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
                {Object.entries(exchangeStatus || {}).map(([exchange, item]) => (
                  <div key={exchange} style={{ border: `1px solid ${C.border}`, borderRadius: 12, padding: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <strong>{exchange.toUpperCase()}</strong>
                      <span style={{ color: item.connected ? C.green : C.red }}>{item.connected ? 'connected' : 'down'}</span>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 8 }}>
                      <div><div style={{ color: C.muted, fontSize: 10 }}>Streaming</div><div>{item.streaming ? 'yes' : 'no'}</div></div>
                      <div><div style={{ color: C.muted, fontSize: 10 }}>Price</div><div className="mono">${Number(item.price || 0).toFixed(2)}</div></div>
                      <div><div style={{ color: C.muted, fontSize: 10 }}>Balance</div><div className="mono">${Number(item.balance || 0).toFixed(2)}</div></div>
                    </div>
                    <div style={{ color: C.muted, fontSize: 11, marginTop: 6 }}>{item.last_tick_at || 'no stream tick yet'} · {item.message}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="grid">
            <Card title="BALANCES" value={`$${Number(balances?.total_usdt_equivalent || 0).toFixed(2)}`} sub="Free + reserved USDT equivalent">
              <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
                {(balances?.balances || []).map((b) => (
                  <div key={b.exchange} style={{ display: 'flex', justifyContent: 'space-between', border: `1px solid ${C.border}`, borderRadius: 12, padding: 10 }}>
                    <span>{b.exchange.toUpperCase()}</span>
                    <span className="mono">${Number(b.total_usdt).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="LAST ENGINE UPDATE" value={update?.type || 'waiting'} sub={update?.timestamp || 'Awaiting websocket feed'}>
              <pre style={{ whiteSpace: 'pre-wrap', fontSize: 11, color: C.muted, margin: 0 }}>{JSON.stringify(update || {}, null, 2)}</pre>
            </Card>
            <Card title="RECONCILIATION" value={reconciliation?.latest_runtime ? 'active' : 'pending'} sub="Runtime vs exchange state drift tracking">
              <div style={{ marginTop: 12, display: 'grid', gap: 8, maxHeight: 280, overflow: 'auto' }}>
                {(reconciliation?.history || []).slice(0, 10).map((item) => (
                  <div key={item.id} style={{ border: `1px solid ${C.border}`, borderRadius: 12, padding: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <strong>{item.exchange.toUpperCase()}</strong>
                      <span style={{ color: item.status === 'ok' ? C.green : C.red }}>{item.status}</span>
                    </div>
                    <div className="mono" style={{ marginTop: 4 }}>drift ${Number(item.drift_usdt || 0).toFixed(4)}</div>
                    <div style={{ color: C.muted, fontSize: 11 }}>{item.timestamp}</div>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="AUDIT TRAIL" value={String((audit || []).length)} sub="Latest decisions and guardian events">
              <div style={{ marginTop: 12, display: 'grid', gap: 8, maxHeight: 260, overflow: 'auto' }}>
                {(audit || []).slice(0, 10).map((item) => (
                  <div key={item.id} style={{ border: `1px solid ${C.border}`, borderRadius: 12, padding: 10 }}>
                    <div style={{ color: C.purple, fontSize: 11, fontWeight: 700 }}>{item.kind}</div>
                    <div style={{ fontSize: 13 }}>{item.message}</div>
                    <div style={{ color: C.muted, fontSize: 11 }}>{item.timestamp}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}

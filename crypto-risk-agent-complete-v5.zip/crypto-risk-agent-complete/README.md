# Crypto Risk Agent

A risk-first crypto trading monorepo aligned to the uploaded build brief.

## Included in this build

- FastAPI backend with the required operational endpoints:
  - `GET /price`
  - `GET /health`
  - `GET /exchange/status`
  - `GET /reconciliation/status`
  - `GET /balance`
  - `GET /positions`
  - `GET /pnl`
  - `GET /signal/latest`
  - `GET /guardian/status`
  - `GET /orders`
  - `GET /audit`
  - `GET /metrics`
  - `POST /kill-switch`
  - `WS /ws/updates`
- Background engine with:
  - paper-mode price feed simulation
  - prediction engine
  - risk gate
  - guardian halt logic
  - smart exchange routing
  - config-driven adapter factory
- Live adapter wiring for CCXT async mode:
  - native stream support for Binance and Bitget public ticker feeds
  - polling fallback for BTCC and stream degradation handling
  - exchange connect/load_markets
  - ticker fetch
  - balance fetch
  - market order placement
  - exchange health checks
- Postgres-backed persistence for:
  - audit events
  - order records
  - metric snapshots
- Config loader using `backend/config/config.yaml`
- JWT gate on write endpoints with Supabase JWKS support and HS256 fallback
- Read-endpoint in-memory rate limiting
- TimescaleDB bootstrap for metric and reconciliation hypertables when available
- CircleCI backend test + paper smoke pipeline
- React + Vite dashboard
- Docker Compose stack for backend, frontend, Redis, and Postgres

## Operating posture

This package is deployable as a **paper environment immediately**.
It is **wired for testnet integration**, but live exchange connectivity has not been validated in this package because credentials and network access are environment-specific.

This pass adds exchange reconciliation snapshots, open-order cancellation inside the kill-switch path, stream-aware market data handling, Supabase JWKS verification, TimescaleDB bootstrap, and an exchange certification script for connect/ticker/balance/health/stream and optional order roundtrip.

## Quick start

1. Copy `.env.example` to `.env`
2. Start the stack:

```bash
docker compose up --build
```

3. Open:
- Frontend: `http://localhost:8080`
- Backend docs: `http://localhost:8000/docs`
- Metrics: `http://localhost:8000/metrics`

## Backend local run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Testnet certification

With credentials loaded and `TRADING_MODE=live`, run:

```bash
cd backend
PYTHONPATH=. python scripts/testnet_certify.py
```

To include authenticated order creation and fetch-order verification:

```bash
PYTHONPATH=. python scripts/testnet_certify.py --place-orders --order-amount 0.0001
```

This validates connect, ticker fetch, balance fetch, health probes, and optional order roundtrip for each configured exchange.

## Delivery status against the brief

Implemented now:
- config-driven runtime
- guardian-first halt path
- audit trail
- rate-limited reads
- bearer-protected write endpoint
- Postgres persistence layer
- websocket broadcast loop
- Dockerized local stack
- CCXT async live adapter structure for Bitget, BTCC, Binance testnet wiring
- exchange health/status endpoint
- reconciliation endpoint and reconciliation persistence
- order placement path split by paper vs live mode
- kill-switch cancellation pass across open exchange orders
- exchange certification script for testnet

Still to wire for full testnet certification:
- authenticated end-to-end order certification on each testnet with real credentials
- exchange-specific production websocket certification for each venue
- Supabase project-secret/JWKS environment validation in target deployment
- CircleCI smoke tests against live exchange testnets
- frontend role-based access controls and operator workflows

## Repository shape

```text
backend/
  app/
    adapters/
    persistence/
    services/
  config/
  scripts/
frontend/
infra/
```

from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal, Any


class SignalPayload(BaseModel):
    direction: Literal['UP', 'DOWN', 'NEUTRAL']
    confidence: float = Field(ge=0, le=1)
    horizon_minutes: float
    recommended_size_fraction: float = Field(ge=0, le=1)
    regime: Literal['TREND', 'RANGE', 'CHAOS']
    exchange_prices: dict[str, float]
    rationale: list[str]
    timestamp: str


class GuardianStatus(BaseModel):
    state: Literal['ACTIVE', 'HALTED']
    last_trigger_reason: str | None = None
    seconds_since_heartbeat: int
    heartbeat_at: str


class PositionView(BaseModel):
    id: str
    exchange: str
    symbol: str
    side: Literal['buy', 'sell']
    size_usdt: float
    entry_price: float
    current_price: float
    unrealized_pnl: float
    status: Literal['open', 'closed']
    opened_at: str
    closed_at: str | None = None


class BalanceView(BaseModel):
    exchange: str
    free_usdt: float
    reserved_usdt: float
    total_usdt: float


class PnLView(BaseModel):
    realized: float
    unrealized: float
    daily: float
    total_capital: float
    by_exchange: dict[str, float]


class AuditEvent(BaseModel):
    id: str
    kind: str
    message: str
    payload: dict[str, Any] = Field(default_factory=dict)
    timestamp: str


class HealthView(BaseModel):
    status: Literal['ok', 'degraded', 'halted']
    trading_mode: str
    network: str
    kill_switch_active: bool
    guardian_state: str
    exchange_connectivity: dict[str, bool]
    timestamp: str


class ReconciliationEntry(BaseModel):
    exchange: str
    runtime_balance: float
    exchange_balance: float
    drift_usdt: float
    runtime_open_positions: int
    exchange_open_orders: int
    status: Literal['ok', 'drift', 'error']
    details: dict[str, Any]
    timestamp: str

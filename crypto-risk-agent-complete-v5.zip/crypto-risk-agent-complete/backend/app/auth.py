from __future__ import annotations

import time
from typing import Any

import httpx
import jwt
from fastapi import Header, HTTPException

from app.config import settings

_JWKS_CACHE: dict[str, Any] = {'fetched_at': 0.0, 'jwks': None}
_JWKS_TTL_SECONDS = 300


def _build_jwks_url() -> str | None:
    if settings.supabase_jwks_url:
        return settings.supabase_jwks_url.rstrip('/')
    if settings.supabase_url:
        return settings.supabase_url.rstrip('/') + '/auth/v1/.well-known/jwks.json'
    return None


def _fetch_jwks_document() -> dict[str, Any]:
    now = time.time()
    if _JWKS_CACHE['jwks'] and now - float(_JWKS_CACHE['fetched_at']) < _JWKS_TTL_SECONDS:
        return _JWKS_CACHE['jwks']
    url = _build_jwks_url()
    if not url:
        raise RuntimeError('Supabase JWKS URL not configured')
    with httpx.Client(timeout=5.0) as client:
        response = client.get(url)
        response.raise_for_status()
        jwks = response.json()
    _JWKS_CACHE.update({'fetched_at': now, 'jwks': jwks})
    return jwks


def _verify_with_jwks(token: str) -> dict[str, Any]:
    header = jwt.get_unverified_header(token)
    kid = header.get('kid')
    if not kid:
        raise RuntimeError('JWT missing kid header for JWKS verification')
    jwks = _fetch_jwks_document()
    for key in jwks.get('keys', []):
        if key.get('kid') == kid:
            public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key)
            kwargs: dict[str, Any] = {
                'algorithms': [key.get('alg', 'RS256')],
                'options': {'verify_aud': bool(settings.supabase_jwt_audience)},
            }
            if settings.supabase_jwt_audience:
                kwargs['audience'] = settings.supabase_jwt_audience
            return jwt.decode(token, public_key, **kwargs)
    raise RuntimeError('Matching JWKS key not found')


def verify_bearer(auth_header: str | None) -> None:
    if not settings.auth_enabled:
        return
    if not auth_header:
        raise HTTPException(status_code=401, detail='Missing bearer token')
    scheme, _, token = auth_header.partition(' ')
    if scheme.lower() != 'bearer' or not token:
        raise HTTPException(status_code=401, detail='Invalid authorization header')

    token_error: Exception | None = None
    if _build_jwks_url():
        try:
            _verify_with_jwks(token)
            return
        except Exception as exc:
            token_error = exc
            if not settings.auth_allow_hs256_fallback:
                raise HTTPException(status_code=401, detail='Invalid token') from exc
    try:
        jwt.decode(
            token,
            settings.supabase_jwt_secret,
            algorithms=['HS256'],
            options={'verify_aud': False},
        )
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=401, detail='Invalid token') from token_error or exc


def bearer_dependency(authorization: str | None = Header(default=None)) -> None:
    verify_bearer(authorization)

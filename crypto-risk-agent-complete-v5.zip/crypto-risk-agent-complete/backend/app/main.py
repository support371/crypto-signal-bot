from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import Depends, FastAPI, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, generate_latest
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import bearer_dependency, verify_bearer
from app.config import settings
from app.db.timescale import bootstrap_timescaledb
from app.persistence.db import Base, SessionLocal, engine as db_engine, get_session
from app.persistence.repository import Repository
from app.rate_limit import rate_limit_dependency
from app.schemas import BalanceView, GuardianStatus, HealthView, PnLView, PositionView
from app.services.engine import TradingEngine
from app.services.risk import RiskService
from app.state import RuntimeState
from app.ws import ConnectionManager

state = RuntimeState()
state.bootstrap(settings.exchange_names, settings.total_capital)
ws_manager = ConnectionManager()
engine = TradingEngine(state, ws_manager)
risk_service = RiskService(state)

ORDERS_TOTAL = Counter('orders_total', 'Total orders opened')
RISK_BLOCKS = Counter('risk_blocks_total', 'Total blocked orders')
KILL_SWITCH = Gauge('kill_switch_active', 'Kill switch active (0/1)')
REALIZED_PNL = Gauge('pnl_realized_usdt', 'Realized PnL in USDT')


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with db_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await bootstrap_timescaledb(db_engine)
    await engine.start()
    yield
    await engine.stop()


app = FastAPI(title=settings.app_name, lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_methods=['*'],
    allow_headers=['*'],
    allow_credentials=True,
)


@app.get('/health', response_model=HealthView, dependencies=[Depends(rate_limit_dependency)])
async def health() -> HealthView:
    return HealthView(
        status='halted' if state.halted else 'ok',
        trading_mode=settings.trading_mode,
        network=settings.network,
        kill_switch_active=state.kill_switch_active,
        guardian_state='HALTED' if state.halted else 'ACTIVE',
        exchange_connectivity=state.exchange_connectivity,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@app.get('/exchange/status', dependencies=[Depends(rate_limit_dependency)])
async def exchange_status() -> dict:
    return {
        exchange: {
            'connected': state.exchange_connectivity.get(exchange, False),
            'streaming': state.exchange_streaming.get(exchange, False),
            'last_tick_at': state.exchange_last_tick_at.get(exchange),
            'message': state.exchange_messages.get(exchange, ''),
            'price': state.prices.get(exchange),
            'balance': state.balances.get(exchange),
        }
        for exchange in settings.exchange_names
    }


@app.get('/price', dependencies=[Depends(rate_limit_dependency)])
async def price() -> dict:
    return {
        'symbol': settings.symbol,
        'exchange_prices': state.prices,
        'timestamp': datetime.now(timezone.utc).isoformat(),
    }


@app.get('/reconciliation/status', dependencies=[Depends(rate_limit_dependency)])
async def reconciliation_status(session: AsyncSession = Depends(get_session)) -> dict:
    repo = Repository(session)
    history: list[dict] = []
    try:
        history = await repo.recent_reconciliation()
    except Exception:
        history = []
    return {
        'latest_runtime': state.last_reconciliation,
        'history': history,
    }


@app.get('/balance', dependencies=[Depends(rate_limit_dependency)])
async def balance() -> dict:
    items = []
    total = 0.0
    for exchange, free in state.balances.items():
        reserved = sum(p.size_usdt for p in state.positions if p.exchange == exchange and p.status == 'open')
        item = BalanceView(exchange=exchange, free_usdt=round(free, 2), reserved_usdt=round(reserved, 2), total_usdt=round(free + reserved, 2))
        items.append(item.model_dump())
        total += item.total_usdt
    return {'balances': items, 'total_usdt_equivalent': round(total, 2)}


@app.get('/positions', dependencies=[Depends(rate_limit_dependency)])
async def positions() -> list[dict]:
    return [
        PositionView(
            id=p.id,
            exchange=p.exchange,
            symbol=p.symbol,
            side=p.side,
            size_usdt=p.size_usdt,
            entry_price=p.entry_price,
            current_price=p.current_price,
            unrealized_pnl=p.unrealized_pnl,
            status=p.status,
            opened_at=p.opened_at,
            closed_at=p.closed_at,
        ).model_dump()
        for p in state.positions
    ]


@app.get('/pnl', response_model=PnLView, dependencies=[Depends(rate_limit_dependency)])
async def pnl() -> PnLView:
    REALIZED_PNL.set(risk_service.realized_total())
    return PnLView(
        realized=risk_service.realized_total(),
        unrealized=risk_service.unrealized_total(),
        daily=risk_service.daily_total(),
        total_capital=state.current_total_capital,
        by_exchange=state.realized_pnl_by_exchange,
    )


@app.get('/signal/latest', dependencies=[Depends(rate_limit_dependency)])
async def signal_latest() -> dict:
    return state.last_signal or {}


@app.get('/guardian/status', response_model=GuardianStatus, dependencies=[Depends(rate_limit_dependency)])
async def guardian_status() -> GuardianStatus:
    last = datetime.fromisoformat(state.last_guardian_heartbeat_at)
    seconds = int((datetime.now(timezone.utc) - last).total_seconds())
    return GuardianStatus(
        state='HALTED' if state.halted else 'ACTIVE',
        last_trigger_reason=state.last_guardian_reason,
        seconds_since_heartbeat=seconds,
        heartbeat_at=state.last_guardian_heartbeat_at,
    )


@app.get('/orders', dependencies=[Depends(rate_limit_dependency)])
async def orders(session: AsyncSession = Depends(get_session)) -> list[dict]:
    repo = Repository(session)
    return await repo.orders()


@app.get('/audit', dependencies=[Depends(rate_limit_dependency)])
async def audit(session: AsyncSession = Depends(get_session)) -> list[dict]:
    repo = Repository(session)
    return await repo.recent_audit()


@app.post('/kill-switch', dependencies=[Depends(bearer_dependency)])
async def kill_switch(payload: dict) -> dict:
    state.kill_switch_active = bool(payload.get('active', True))
    state.halted = state.kill_switch_active
    state.last_guardian_reason = payload.get('reason', 'Manual kill switch')
    KILL_SWITCH.set(1 if state.kill_switch_active else 0)
    return {'active': state.kill_switch_active, 'reason': state.last_guardian_reason}


@app.get('/metrics', dependencies=[Depends(rate_limit_dependency)])
async def metrics() -> Response:
    KILL_SWITCH.set(1 if state.kill_switch_active else 0)
    REALIZED_PNL.set(risk_service.realized_total())
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.websocket('/ws/updates')
async def websocket_updates(websocket: WebSocket) -> None:
    auth = websocket.headers.get('authorization')
    if settings.auth_enabled and auth:
        verify_bearer(auth)
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

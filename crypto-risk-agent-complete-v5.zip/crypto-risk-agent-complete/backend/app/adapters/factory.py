from __future__ import annotations

from app.adapters.live import LiveCcxtAdapter
from app.adapters.paper import PaperExchangeAdapter
from app.config import settings
from app.state import RuntimeState


def build_adapter(name: str, state: RuntimeState):
    if settings.trading_mode == 'live':
        return LiveCcxtAdapter(name=name, state=state)
    return PaperExchangeAdapter(name=name, state=state)

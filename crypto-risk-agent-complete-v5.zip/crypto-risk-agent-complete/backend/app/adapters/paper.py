from __future__ import annotations

import random
from typing import Any

from app.adapters.base import PriceCallback
from app.state import RuntimeState


class PaperExchangeAdapter:
    def __init__(self, name: str, state: RuntimeState) -> None:
        self.name = name
        self.state = state
        self._rnd = random.Random(hash(name) & 0xFFFF)

    async def connect(self) -> None:
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'paper adapter ready'

    async def close(self) -> None:
        self.state.exchange_connectivity[self.name] = False
        self.state.exchange_messages[self.name] = 'paper adapter closed'

    async def fetch_ticker(self, symbol: str) -> float:
        current = self.state.prices[self.name]
        drift = self._rnd.uniform(-0.0015, 0.0015)
        return round(current * (1 + drift), 2)

    async def fetch_balance(self) -> float:
        return self.state.balances[self.name]

    async def create_market_order(self, symbol: str, side: str, amount: float) -> dict[str, Any]:
        return {
            'id': f'paper-{self.name}-{self._rnd.randint(100000,999999)}',
            'symbol': symbol,
            'side': side,
            'amount': amount,
            'status': 'closed',
            'average': self.state.prices[self.name],
        }

    async def fetch_order(self, order_id: str, symbol: str) -> dict[str, Any]:
        return {
            'id': order_id,
            'symbol': symbol,
            'status': 'closed',
            'filled': 1.0,
            'remaining': 0.0,
            'average': self.state.prices[self.name],
        }

    async def fetch_open_orders(self, symbol: str) -> list[dict[str, Any]]:
        return []

    async def cancel_order(self, order_id: str, symbol: str) -> dict[str, Any]:
        return {
            'id': order_id,
            'symbol': symbol,
            'status': 'canceled',
        }

    async def health(self) -> tuple[bool, str]:
        return True, 'paper adapter ready'

    async def start_ticker_stream(self, symbol: str, callback: PriceCallback) -> bool:
        return False

    async def stop_ticker_stream(self) -> None:
        return None

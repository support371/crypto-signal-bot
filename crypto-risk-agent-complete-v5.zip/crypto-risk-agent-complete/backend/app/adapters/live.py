from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from typing import Any

import ccxt.async_support as ccxt_async

from app.adapters.base import PriceCallback
from app.config import settings
from app.state import RuntimeState, utc_iso

try:  # pragma: no cover - runtime dependency from uvicorn[standard]
    import websockets
except Exception:  # pragma: no cover
    websockets = None


class LiveCcxtAdapter:
    def __init__(self, name: str, state: RuntimeState) -> None:
        self.name = name
        self.state = state
        self._client: Any | None = None
        self._stream_task: asyncio.Task | None = None
        self._stream_stop = asyncio.Event()

    def _credentials(self) -> dict[str, Any]:
        if self.name == 'binance':
            return {
                'apiKey': settings.binance_api_key,
                'secret': settings.binance_api_secret,
                'enableRateLimit': True,
            }
        if self.name == 'bitget':
            return {
                'apiKey': settings.bitget_api_key,
                'secret': settings.bitget_api_secret,
                'password': settings.bitget_passphrase,
                'enableRateLimit': True,
            }
        if self.name == 'btcc':
            return {
                'apiKey': settings.btcc_api_key,
                'secret': settings.btcc_api_secret,
                'enableRateLimit': True,
            }
        raise ValueError(f'Unsupported exchange: {self.name}')

    def _sandbox_enabled(self) -> bool:
        return bool(getattr(settings, f'{self.name}_sandbox', False)) and settings.network == 'testnet'

    def _override_urls(self) -> dict[str, Any] | None:
        rest_url = getattr(settings, f'{self.name}_testnet_rest_url', None)
        if not rest_url:
            return None
        return {'api': {'public': rest_url, 'private': rest_url}}

    def _client_class(self):
        try:
            return getattr(ccxt_async, self.name)
        except AttributeError as exc:
            raise RuntimeError(f'CCXT exchange class unavailable for {self.name}') from exc

    def _ws_url(self) -> str | None:
        return getattr(settings, f'{self.name}_ws_url', None)

    async def connect(self) -> None:
        if self._client is not None:
            return
        params = self._credentials()
        override_urls = self._override_urls()
        if override_urls:
            params['urls'] = override_urls
        client_cls = self._client_class()
        self._client = client_cls(params)
        if self.name == 'binance' and self._sandbox_enabled() and hasattr(self._client, 'set_sandbox_mode'):
            self._client.set_sandbox_mode(True)
        try:
            await self._client.load_markets()
            self.state.exchange_connectivity[self.name] = True
            self.state.exchange_messages[self.name] = 'connected'
        except Exception as exc:
            self.state.exchange_connectivity[self.name] = False
            self.state.exchange_messages[self.name] = f'connect failed: {exc}'
            self.state.api_error_count += 1
            raise

    async def close(self) -> None:
        await self.stop_ticker_stream()
        if self._client is not None:
            await self._client.close()
            self._client = None
        self.state.exchange_connectivity[self.name] = False
        self.state.exchange_messages[self.name] = 'closed'

    async def _ensure(self) -> Any:
        if self._client is None:
            await self.connect()
        return self._client

    async def fetch_ticker(self, symbol: str) -> float:
        client = await self._ensure()
        ticker = await client.fetch_ticker(symbol)
        price = ticker.get('last') or ticker.get('close') or ticker.get('bid') or ticker.get('ask')
        if price is None:
            raise RuntimeError(f'No ticker price returned by {self.name} for {symbol}')
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'ticker ok'
        return float(price)

    async def fetch_balance(self) -> float:
        client = await self._ensure()
        balance = await client.fetch_balance()
        total = balance.get('total') or {}
        for quote in ('USDT', 'USD', 'USDC'):
            value = total.get(quote)
            if value is not None:
                self.state.exchange_connectivity[self.name] = True
                self.state.exchange_messages[self.name] = f'balance ok {quote}'
                return float(value)
        free = balance.get('free') or {}
        for quote in ('USDT', 'USD', 'USDC'):
            value = free.get(quote)
            if value is not None:
                self.state.exchange_connectivity[self.name] = True
                self.state.exchange_messages[self.name] = f'balance ok {quote} free'
                return float(value)
        return 0.0

    async def create_market_order(self, symbol: str, side: str, amount: float) -> dict[str, Any]:
        client = await self._ensure()
        order = await client.create_order(symbol=symbol, type='market', side=side, amount=amount)
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'order ok'
        return order

    async def fetch_order(self, order_id: str, symbol: str) -> dict[str, Any]:
        client = await self._ensure()
        order = await client.fetch_order(order_id, symbol)
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'fetch_order ok'
        return order

    async def fetch_open_orders(self, symbol: str) -> list[dict[str, Any]]:
        client = await self._ensure()
        orders = await client.fetch_open_orders(symbol)
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'fetch_open_orders ok'
        return orders

    async def cancel_order(self, order_id: str, symbol: str) -> dict[str, Any]:
        client = await self._ensure()
        order = await client.cancel_order(order_id, symbol)
        self.state.exchange_connectivity[self.name] = True
        self.state.exchange_messages[self.name] = 'cancel_order ok'
        return order

    async def health(self) -> tuple[bool, str]:
        try:
            client = await self._ensure()
            if getattr(client, 'has', {}).get('fetchStatus', False):
                await client.fetch_status()
            else:
                await client.fetch_time()
            self.state.exchange_connectivity[self.name] = True
            self.state.exchange_messages[self.name] = 'health ok'
            return True, 'health ok'
        except Exception as exc:
            self.state.exchange_connectivity[self.name] = False
            self.state.exchange_messages[self.name] = f'health failed: {exc}'
            self.state.api_error_count += 1
            return False, str(exc)

    async def start_ticker_stream(self, symbol: str, callback: PriceCallback) -> bool:
        if websockets is None or self.name not in {'binance', 'bitget'}:
            self.state.exchange_streaming[self.name] = False
            return False
        if self._stream_task and not self._stream_task.done():
            return True
        self._stream_stop = asyncio.Event()
        self._stream_task = asyncio.create_task(self._stream_loop(symbol, callback))
        return True

    async def stop_ticker_stream(self) -> None:
        self._stream_stop.set()
        if self._stream_task and not self._stream_task.done():
            self._stream_task.cancel()
            try:
                await self._stream_task
            except asyncio.CancelledError:
                pass
        self._stream_task = None
        self.state.exchange_streaming[self.name] = False

    async def _stream_loop(self, symbol: str, callback: PriceCallback) -> None:
        backoff = 1.0
        while not self._stream_stop.is_set():
            try:
                if self.name == 'binance':
                    await self._stream_binance(symbol, callback)
                elif self.name == 'bitget':
                    await self._stream_bitget(symbol, callback)
                backoff = 1.0
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.state.exchange_streaming[self.name] = False
                self.state.exchange_messages[self.name] = f'stream reconnect: {exc}'
                self.state.api_error_count += 1
                await asyncio.sleep(min(backoff, 10.0))
                backoff *= 2

    async def _stream_binance(self, symbol: str, callback: PriceCallback) -> None:
        pair = symbol.replace('/', '').lower()
        base_url = self._ws_url() or 'wss://stream.binance.com:9443/ws'
        url = f'{base_url.rstrip('/')}/{pair}@ticker'
        async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
            self.state.exchange_streaming[self.name] = True
            self.state.exchange_messages[self.name] = 'stream connected'
            async for raw in ws:
                if self._stream_stop.is_set():
                    break
                data = json.loads(raw)
                price = data.get('c') or data.get('C') or data.get('p')
                if price is None:
                    continue
                await callback(self.name, float(price))

    async def _stream_bitget(self, symbol: str, callback: PriceCallback) -> None:
        inst_id = symbol.replace('/', '').upper()
        url = (self._ws_url() or 'wss://ws.bitget.com/v2/ws/public').rstrip('/')
        async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
            sub_msg = {
                'op': 'subscribe',
                'args': [{'instType': 'SPOT', 'channel': 'ticker', 'instId': inst_id}],
            }
            await ws.send(json.dumps(sub_msg))
            self.state.exchange_streaming[self.name] = True
            self.state.exchange_messages[self.name] = 'stream connected'
            async for raw in ws:
                if self._stream_stop.is_set():
                    break
                data = json.loads(raw)
                items = data.get('data') or []
                if not items:
                    continue
                item = items[0]
                price = item.get('lastPr') or item.get('close')
                if price is None:
                    continue
                await callback(self.name, float(price))

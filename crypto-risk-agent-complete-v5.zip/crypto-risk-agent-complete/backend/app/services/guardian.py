from __future__ import annotations

from app.config import settings
from app.state import RuntimeState, utc_iso
from app.services.execution import ExecutionService
from app.services.risk import RiskService


class GuardianService:
    def __init__(self, state: RuntimeState, risk: RiskService, execution: ExecutionService) -> None:
        self.state = state
        self.risk = risk
        self.execution = execution

    def heartbeat(self) -> None:
        self.state.last_guardian_heartbeat_at = utc_iso()

    async def evaluate(self) -> tuple[bool, str | None]:
        drawdown = self.risk.drawdown_fraction()
        daily_loss_fraction = abs(min(0.0, self.risk.daily_total())) / max(self.state.current_total_capital, 1)

        reason = None
        if self.state.api_error_count >= settings.api_error_kill_threshold:
            reason = 'API error threshold reached'
        elif self.state.failed_order_count >= settings.failed_order_kill_threshold:
            reason = 'Failed order threshold reached'
        elif drawdown >= settings.drawdown_trigger_fraction:
            reason = 'Drawdown trigger breached'
        elif daily_loss_fraction >= settings.daily_loss_limit_fraction:
            reason = 'Daily loss trigger breached'
        elif (self.state.last_signal or {}).get('regime') == 'CHAOS':
            reason = 'CHAOS regime detected'

        if reason:
            self.state.kill_switch_active = True
            self.state.halted = True
            self.state.last_guardian_reason = reason
            await self.execution.cancel_all_open_orders()
            await self.execution.force_liquidate_all()
            return False, reason
        return True, None

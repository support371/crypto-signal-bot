from __future__ import annotations

import asyncio

from app.config import settings
from app.persistence.repository import Repository
from app.state import RuntimeState, utc_iso


class ReconciliationService:
    def __init__(self, state: RuntimeState, adapters: dict, session_factory=None) -> None:
        self.state = state
        self.adapters = adapters
        self.session_factory = session_factory

    async def snapshot(self) -> dict[str, dict]:
        report: dict[str, dict] = {}
        for exchange, adapter in self.adapters.items():
            runtime_balance = round(self.state.balances.get(exchange, 0.0), 8)
            runtime_open_positions = len(
                [p for p in self.state.positions if p.exchange == exchange and p.status == 'open']
            )
            try:
                exchange_balance = round(await adapter.fetch_balance(), 8)
                open_orders = await adapter.fetch_open_orders(settings.symbol)
                exchange_open_orders = len(open_orders)
                drift_usdt = round(exchange_balance - runtime_balance, 8)
                status = 'ok' if abs(drift_usdt) <= settings.reconciliation_drift_tolerance_usdt and exchange_open_orders == runtime_open_positions else 'drift'
                details = {
                    'open_order_ids': [str(order.get('id')) for order in open_orders],
                    'runtime_position_ids': [p.id for p in self.state.positions if p.exchange == exchange and p.status == 'open'],
                }
            except Exception as exc:
                exchange_balance = runtime_balance
                exchange_open_orders = 0
                drift_usdt = 0.0
                status = 'error'
                details = {'error': str(exc)}

            entry = {
                'exchange': exchange,
                'runtime_balance': runtime_balance,
                'exchange_balance': exchange_balance,
                'drift_usdt': drift_usdt,
                'runtime_open_positions': runtime_open_positions,
                'exchange_open_orders': exchange_open_orders,
                'status': status,
                'details': details,
                'timestamp': utc_iso(),
            }
            report[exchange] = entry
            self._persist(entry)
        self.state.last_reconciliation = report
        return report

    def _persist(self, entry: dict) -> None:
        if not self.session_factory:
            return
        asyncio.create_task(self._persist_async(entry))

    async def _persist_async(self, entry: dict) -> None:
        try:
            async with self.session_factory() as session:
                repo = Repository(session)
                await repo.add_reconciliation_snapshot(
                    exchange=entry['exchange'],
                    runtime_balance=entry['runtime_balance'],
                    exchange_balance=entry['exchange_balance'],
                    drift_usdt=entry['drift_usdt'],
                    runtime_open_positions=entry['runtime_open_positions'],
                    exchange_open_orders=entry['exchange_open_orders'],
                    status=entry['status'],
                    details=entry['details'],
                )
        except Exception:
            return

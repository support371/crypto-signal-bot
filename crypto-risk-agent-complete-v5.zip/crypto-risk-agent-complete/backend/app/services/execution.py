from __future__ import annotations

import asyncio
from typing import Any

from app.config import settings
from app.persistence.repository import Repository
from app.state import RuntimePosition, RuntimeState, utc_iso


class ExecutionService:
    def __init__(self, state: RuntimeState, adapters: dict[str, Any], session_factory=None) -> None:
        self.state = state
        self.adapters = adapters
        self.session_factory = session_factory

    def route_exchange(self, side: str) -> list[str]:
        prices = self.state.prices
        ranked = sorted(prices.keys(), key=prices.get, reverse=(side == 'sell'))
        return ranked

    async def maybe_enter(self, signal: dict) -> RuntimePosition | None:
        if signal['direction'] not in {'UP', 'DOWN'} or signal['recommended_size_fraction'] <= 0:
            return None
        side = 'buy' if signal['direction'] == 'UP' else 'sell'
        size_usdt = round(self.state.current_total_capital * signal['recommended_size_fraction'], 2)
        exchanges = self.route_exchange(side)
        for exchange in exchanges:
            if self.state.balances.get(exchange, 0.0) < size_usdt:
                continue
            price = self.state.prices[exchange]
            quantity = round(size_usdt / max(price, 1), 8)
            try:
                order_id = None
                if settings.trading_mode == 'live':
                    order = await self.adapters[exchange].create_market_order(settings.symbol, side, quantity)
                    order_id = str(order.get('id')) if isinstance(order, dict) else None
                else:
                    order = await self.adapters[exchange].create_market_order(settings.symbol, side, quantity)
                    order_id = str(order.get('id'))
                position = RuntimePosition(
                    exchange=exchange,
                    symbol=settings.symbol,
                    side=side,
                    size_usdt=size_usdt,
                    entry_price=price,
                    current_price=price,
                    quantity=quantity,
                    order_id=order_id,
                )
                self.state.positions.append(position)
                self.state.balances[exchange] -= size_usdt
                self._persist_position(position)
                self.state.exchange_connectivity[exchange] = True
                self.state.exchange_messages[exchange] = 'order opened'
                return position
            except Exception as exc:
                self.state.failed_order_count += 1
                self.state.exchange_connectivity[exchange] = False
                self.state.exchange_messages[exchange] = f'order failed: {exc}'
                continue
        return None

    def mark_positions(self) -> None:
        for position in self.state.positions:
            if position.status == 'open':
                position.current_price = self.state.prices[position.exchange]
                self._persist_position(position)

    async def maybe_close_winners_or_timers(self) -> list[RuntimePosition]:
        closed: list[RuntimePosition] = []
        for position in self.state.positions:
            if position.status != 'open':
                continue
            pnl_fraction = position.unrealized_pnl / max(position.size_usdt, 1)
            if pnl_fraction >= 0.006 or pnl_fraction <= -0.004:
                await self._close_position(position)
                closed.append(position)
        return closed

    async def force_liquidate_all(self) -> list[RuntimePosition]:
        closed: list[RuntimePosition] = []
        for position in self.state.positions:
            if position.status != 'open':
                continue
            await self._close_position(position)
            closed.append(position)
        return closed

    async def cancel_all_open_orders(self) -> list[dict]:
        cancelled: list[dict] = []
        for exchange, adapter in self.adapters.items():
            try:
                orders = await adapter.fetch_open_orders(settings.symbol)
                for order in orders:
                    order_id = str(order.get('id'))
                    result = await adapter.cancel_order(order_id, settings.symbol)
                    cancelled.append({'exchange': exchange, 'order_id': order_id, 'status': result.get('status')})
                self.state.exchange_messages[exchange] = 'open orders cancelled'
            except Exception as exc:
                self.state.failed_order_count += 1
                self.state.exchange_connectivity[exchange] = False
                self.state.exchange_messages[exchange] = f'cancel failed: {exc}'
        return cancelled

    async def _close_position(self, position: RuntimePosition) -> None:
        if position.status != 'open':
            return
        exit_side = 'sell' if position.side == 'buy' else 'buy'
        try:
            if settings.trading_mode == 'live':
                order = await self.adapters[position.exchange].create_market_order(position.symbol, exit_side, position.quantity)
                position.exit_order_id = str(order.get('id')) if isinstance(order, dict) else None
            else:
                order = await self.adapters[position.exchange].create_market_order(position.symbol, exit_side, position.quantity)
                position.exit_order_id = str(order.get('id'))
        except Exception as exc:
            self.state.failed_order_count += 1
            self.state.exchange_connectivity[position.exchange] = False
            self.state.exchange_messages[position.exchange] = f'close failed: {exc}'
            return
        position.status = 'closed'
        position.closed_at = utc_iso()
        pnl = position.unrealized_pnl
        self.state.realized_pnl_by_exchange[position.exchange] += pnl
        self.state.balances[position.exchange] += position.size_usdt + pnl
        self._persist_position(position)
        self.state.exchange_messages[position.exchange] = 'position closed'

    def _persist_position(self, position: RuntimePosition) -> None:
        if not self.session_factory:
            return
        payload = {
            'id': position.id,
            'exchange': position.exchange,
            'symbol': position.symbol,
            'side': position.side,
            'size_usdt': position.size_usdt,
            'entry_price': position.entry_price,
            'current_price': position.current_price,
            'unrealized_pnl': position.unrealized_pnl,
            'status': position.status,
            'opened_at': position.opened_at,
            'closed_at': position.closed_at,
        }
        asyncio.create_task(self._persist_order(payload))

    async def _persist_order(self, payload: dict) -> None:
        try:
            async with self.session_factory() as session:
                repo = Repository(session)
                await repo.upsert_order(payload)
        except Exception:
            return

from __future__ import annotations

import asyncio

from app.adapters.factory import build_adapter
from app.config import settings
from app.state import RuntimeState, utc_iso


class MarketService:
    def __init__(self, state: RuntimeState) -> None:
        self.state = state
        self.adapters = {name: build_adapter(name, state) for name in state.prices.keys()}

    async def connect(self) -> None:
        results = await asyncio.gather(*(adapter.connect() for adapter in self.adapters.values()), return_exceptions=True)
        for exchange, result in zip(self.adapters.keys(), results):
            if isinstance(result, Exception):
                self.state.exchange_connectivity[exchange] = False
                self.state.exchange_messages[exchange] = f'connect failed: {result}'
                self.state.api_error_count += 1
        if settings.trading_mode == 'live' and settings.use_exchange_streams:
            for exchange, adapter in self.adapters.items():
                try:
                    started = await adapter.start_ticker_stream(settings.symbol, self._on_stream_price)
                    self.state.exchange_streaming[exchange] = started
                    if not started:
                        self.state.exchange_messages[exchange] = 'polling fallback active'
                except Exception as exc:
                    self.state.exchange_streaming[exchange] = False
                    self.state.exchange_messages[exchange] = f'stream start failed: {exc}'

    async def close(self) -> None:
        await asyncio.gather(*(adapter.stop_ticker_stream() for adapter in self.adapters.values()), return_exceptions=True)
        await asyncio.gather(*(adapter.close() for adapter in self.adapters.values()), return_exceptions=True)

    async def _on_stream_price(self, exchange: str, price: float) -> None:
        self.state.prices[exchange] = round(float(price), 8)
        self.state.exchange_connectivity[exchange] = True
        self.state.exchange_streaming[exchange] = True
        self.state.exchange_last_tick_at[exchange] = utc_iso()
        self.state.exchange_messages[exchange] = 'stream tick ok'

    def _stream_fresh(self, exchange: str) -> bool:
        last = self.state.exchange_last_tick_at.get(exchange)
        if not last:
            return False
        try:
            from datetime import datetime, timezone
            elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last)).total_seconds()
            return elapsed <= settings.price_poll_fallback_seconds
        except Exception:
            return False

    async def refresh_prices(self) -> dict[str, float]:
        updated: dict[str, float] = {}
        for exchange, adapter in self.adapters.items():
            if settings.trading_mode == 'live' and self.state.exchange_streaming.get(exchange) and self._stream_fresh(exchange):
                updated[exchange] = self.state.prices.get(exchange, 0.0)
                continue
            try:
                updated[exchange] = await adapter.fetch_ticker(settings.symbol)
                self.state.exchange_connectivity[exchange] = True
                self.state.exchange_last_tick_at[exchange] = utc_iso()
            except Exception as exc:
                self.state.api_error_count += 1
                self.state.exchange_connectivity[exchange] = False
                self.state.exchange_messages[exchange] = f'ticker failed: {exc}'
                updated[exchange] = self.state.prices.get(exchange, 0.0)
        self.state.prices = updated
        return updated

    async def refresh_balances(self) -> dict[str, float]:
        balances: dict[str, float] = {}
        for exchange, adapter in self.adapters.items():
            try:
                balances[exchange] = await adapter.fetch_balance()
                self.state.exchange_connectivity[exchange] = True
            except Exception as exc:
                self.state.api_error_count += 1
                self.state.exchange_connectivity[exchange] = False
                self.state.exchange_messages[exchange] = f'balance failed: {exc}'
                balances[exchange] = self.state.balances.get(exchange, 0.0)
        self.state.balances.update(balances)
        return self.state.balances

    async def health(self) -> dict[str, dict[str, str | bool]]:
        report: dict[str, dict[str, str | bool]] = {}
        for exchange, adapter in self.adapters.items():
            ok, message = await adapter.health()
            report[exchange] = {
                'connected': ok,
                'message': message,
                'streaming': self.state.exchange_streaming.get(exchange, False),
                'last_tick_at': self.state.exchange_last_tick_at.get(exchange),
            }
        return report

from __future__ import annotations
from app.config import settings
from app.state import RuntimeState


class RiskService:
    def __init__(self, state: RuntimeState) -> None:
        self.state = state

    def exposure_fraction(self) -> float:
        open_exposure = sum(p.size_usdt for p in self.state.positions if p.status == 'open')
        return open_exposure / max(self.state.current_total_capital, 1)

    def unrealized_total(self) -> float:
        return round(sum(p.unrealized_pnl for p in self.state.positions if p.status == 'open'), 2)

    def realized_total(self) -> float:
        return round(sum(self.state.realized_pnl_by_exchange.values()), 2)

    def daily_total(self) -> float:
        return round(self.realized_total() + self.unrealized_total(), 2)

    def drawdown_fraction(self) -> float:
        if self.state.equity_high_water_mark <= 0:
            return 0.0
        return max(0.0, (self.state.equity_high_water_mark - self.state.current_total_capital) / self.state.equity_high_water_mark)

    def can_enter(self, signal: dict) -> tuple[bool, str | None]:
        if self.state.kill_switch_active or self.state.halted:
            return False, 'System halted'
        if signal['regime'] == 'CHAOS':
            return False, 'CHAOS regime'
        if signal['confidence'] < settings.min_signal_confidence:
            return False, 'Confidence below minimum'
        if self.exposure_fraction() + signal['recommended_size_fraction'] > settings.max_capital_exposure_fraction:
            return False, 'Exposure limit exceeded'
        if signal['recommended_size_fraction'] > settings.max_single_position_fraction:
            return False, 'Single-position cap exceeded'
        if abs(self.daily_total()) / max(self.state.current_total_capital, 1) > settings.daily_loss_limit_fraction:
            return False, 'Daily loss threshold reached'
        return True, None

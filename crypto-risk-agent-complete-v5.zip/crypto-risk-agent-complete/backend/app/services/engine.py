from __future__ import annotations

import asyncio

from app.config import settings
from app.persistence.db import SessionLocal
from app.persistence.repository import Repository
from app.state import RuntimeState, utc_iso
from app.ws import ConnectionManager
from app.services.audit import AuditService
from app.services.market import MarketService
from app.services.prediction import PredictionService
from app.services.risk import RiskService
from app.services.execution import ExecutionService
from app.services.guardian import GuardianService
from app.services.reconciliation import ReconciliationService


class TradingEngine:
    def __init__(self, state: RuntimeState, ws: ConnectionManager) -> None:
        self.state = state
        self.ws = ws
        self.audit = AuditService(state, SessionLocal)
        self.market = MarketService(state)
        self.prediction = PredictionService(state)
        self.risk = RiskService(state)
        self.execution = ExecutionService(state, self.market.adapters, SessionLocal)
        self.guardian = GuardianService(state, self.risk, self.execution)
        self.reconciliation = ReconciliationService(state, self.market.adapters, SessionLocal)
        self._task: asyncio.Task | None = None

    async def initialize(self) -> None:
        await self.market.connect()
        if settings.trading_mode == 'live':
            await self.market.refresh_balances()

    def total_capital(self) -> float:
        balances = sum(self.state.balances.values())
        unrealized = self.risk.unrealized_total()
        total = round(balances + sum(p.size_usdt for p in self.state.positions if p.status == 'open') + unrealized, 2)
        self.state.current_total_capital = total
        self.state.equity_high_water_mark = max(self.state.equity_high_water_mark, total)
        return total

    async def tick(self) -> None:
        await self.market.refresh_prices()
        await self.market.refresh_balances()
        self.execution.mark_positions()
        signal = self.prediction.generate()
        self.guardian.heartbeat()

        can_enter, reason = self.risk.can_enter(signal)
        if can_enter:
            position = await self.execution.maybe_enter(signal)
            if position:
                self.audit.record('order_opened', f'Opened {position.side} on {position.exchange}', {
                    'position_id': position.id,
                    'size_usdt': position.size_usdt,
                    'entry_price': position.entry_price,
                    'order_id': position.order_id,
                })
                if settings.trading_mode == 'live':
                    from app.main import ORDERS_TOTAL
                    ORDERS_TOTAL.inc()
        elif reason:
            self.audit.record('risk_block', reason, {'signal': signal})
            from app.main import RISK_BLOCKS
            RISK_BLOCKS.inc()

        closed = await self.execution.maybe_close_winners_or_timers()
        for position in closed:
            self.audit.record('order_closed', f'Closed {position.side} on {position.exchange}', {
                'position_id': position.id,
                'pnl': position.unrealized_pnl,
                'exit_order_id': position.exit_order_id,
            })

        self.total_capital()
        _, guardian_reason = await self.guardian.evaluate()
        if guardian_reason:
            self.audit.record('guardian_trigger', guardian_reason, {})

        await self.reconciliation.snapshot()

        await self._persist_metrics()
        await self.ws.broadcast_json({
            'type': 'engine_update',
            'timestamp': utc_iso(),
            'signal': self.state.last_signal,
            'guardian': {
                'state': 'HALTED' if self.state.halted else 'ACTIVE',
                'last_trigger_reason': self.state.last_guardian_reason,
            },
            'pnl': {
                'realized': self.risk.realized_total(),
                'unrealized': self.risk.unrealized_total(),
                'daily': self.risk.daily_total(),
                'total_capital': self.state.current_total_capital,
            },
            'connectivity': self.state.exchange_connectivity,
            'reconciliation': self.state.last_reconciliation,
        })

    async def _persist_metrics(self) -> None:
        try:
            async with SessionLocal() as session:
                repo = Repository(session)
                await repo.add_metric_snapshot(
                    total_capital=self.state.current_total_capital,
                    realized_pnl=self.risk.realized_total(),
                    unrealized_pnl=self.risk.unrealized_total(),
                    daily_pnl=self.risk.daily_total(),
                )
        except Exception:
            return

    async def run_forever(self) -> None:
        while True:
            await self.tick()
            await asyncio.sleep(settings.engine_tick_seconds)

    async def start(self) -> None:
        await self.initialize()
        if not self._task or self._task.done():
            self._task = asyncio.create_task(self.run_forever())

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.market.close()

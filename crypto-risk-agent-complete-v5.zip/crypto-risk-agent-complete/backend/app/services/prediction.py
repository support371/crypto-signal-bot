from __future__ import annotations
from app.config import settings
from app.state import RuntimeState, utc_iso


class PredictionService:
    def __init__(self, state: RuntimeState) -> None:
        self.state = state

    def generate(self) -> dict:
        prices = self.state.prices
        values = list(prices.values())
        best = min(values)
        worst = max(values)
        spread_fraction = (worst - best) / max(best, 1)
        avg_price = sum(values) / len(values)
        imbalance = ((prices['binance'] - avg_price) + (prices['bitget'] - avg_price) + (prices['btcc'] - avg_price)) / avg_price

        if spread_fraction > 0.004:
            regime = 'CHAOS'
            direction = 'NEUTRAL'
            confidence = 0.25
            size_fraction = 0.0
            rationale = ['Cross-exchange spread breached chaos threshold']
        else:
            regime = 'TREND' if abs(imbalance) > 0.0004 else 'RANGE'
            direction = 'UP' if imbalance >= 0 else 'DOWN'
            confidence = min(0.95, max(settings.min_signal_confidence, 0.68 + abs(imbalance) * 50))
            if confidence < 0.70:
                size_fraction = 0.005
            elif confidence < 0.80:
                size_fraction = 0.01
            elif confidence < 0.90:
                size_fraction = 0.02
            else:
                size_fraction = settings.max_single_position_fraction
            rationale = [
                f'Imbalance score: {imbalance:.6f}',
                f'Cross-exchange spread: {spread_fraction:.4%}',
                f'Regime classified as {regime}',
            ]

        signal = {
            'direction': direction,
            'confidence': round(confidence, 4),
            'horizon_minutes': 2.0,
            'recommended_size_fraction': round(size_fraction, 4),
            'regime': regime,
            'exchange_prices': prices,
            'rationale': rationale,
            'timestamp': utc_iso(),
        }
        self.state.last_signal = signal
        return signal

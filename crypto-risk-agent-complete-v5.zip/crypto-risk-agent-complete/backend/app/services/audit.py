from __future__ import annotations

import asyncio
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from app.persistence.repository import Repository
from app.state import RuntimeState, utc_iso


class AuditService:
    def __init__(self, state: RuntimeState, session_factory=None) -> None:
        self.state = state
        self.session_factory = session_factory

    def record(self, kind: str, message: str, payload: dict | None = None) -> None:
        event = {
            'id': str(uuid4()),
            'kind': kind,
            'message': message,
            'payload': payload or {},
            'timestamp': utc_iso(),
        }
        self.state.audit.insert(0, event)
        self.state.audit = self.state.audit[:250]
        if self.session_factory:
            asyncio.create_task(self._persist_event(event))

    async def _persist_event(self, event: dict) -> None:
        try:
            async with self.session_factory() as session:
                repo = Repository(session)
                await repo.add_audit_event(event)
        except Exception:
            return

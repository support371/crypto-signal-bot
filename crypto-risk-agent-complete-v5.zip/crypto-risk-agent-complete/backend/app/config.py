from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


ROOT_DIR = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH = ROOT_DIR / 'config' / 'config.yaml'


def _load_yaml_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    return data if isinstance(data, dict) else {}


_yaml = _load_yaml_config(DEFAULT_CONFIG_PATH)


def _cfg(path: str, default: Any) -> Any:
    cur: Any = _yaml
    for part in path.split('.'):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_ignore_empty=True, extra='ignore')

    app_name: str = _cfg('app.name', 'Crypto Risk Agent')
    app_env: str = _cfg('app.env', 'development')
    api_prefix: str = '/api'
    cors_origins: str = _cfg('app.cors_origins', 'http://localhost:5173,http://localhost:8080')
    internal_secret: str = 'change-me'
    supabase_jwt_secret: str = 'change-me'
    supabase_url: str | None = _cfg('auth.supabase_url', None)
    supabase_jwks_url: str | None = _cfg('auth.supabase_jwks_url', None)
    supabase_jwt_audience: str | None = _cfg('auth.supabase_jwt_audience', None)
    auth_allow_hs256_fallback: bool = bool(_cfg('auth.allow_hs256_fallback', True))
    auth_enabled: bool = bool(_cfg('auth.enabled', True))
    read_rate_limit_per_minute: int = int(_cfg('auth.read_rate_limit_per_minute', 120))

    trading_mode: str = Field(default=_cfg('engine.trading_mode', 'paper'))  # paper | live
    network: str = Field(default=_cfg('engine.network', 'testnet'))  # testnet | mainnet
    symbol: str = _cfg('engine.symbol', 'BTC/USDT')
    total_capital: float = float(_cfg('engine.total_capital', 10000.0))
    heartbeat_seconds: int = int(_cfg('engine.heartbeat_seconds', 5))
    balance_refresh_seconds: int = int(_cfg('engine.balance_refresh_seconds', 10))
    engine_tick_seconds: int = int(_cfg('engine.engine_tick_seconds', 2))
    use_exchange_streams: bool = bool(_cfg('engine.use_exchange_streams', True))
    price_poll_fallback_seconds: int = int(_cfg('engine.price_poll_fallback_seconds', 15))
    reconciliation_drift_tolerance_usdt: float = float(_cfg('engine.reconciliation_drift_tolerance_usdt', 1.0))
    certification_order_amount: float = float(_cfg('engine.certification_order_amount', 0.0001))

    max_capital_exposure_fraction: float = float(_cfg('risk.max_capital_exposure_fraction', 0.05))
    max_single_position_fraction: float = float(_cfg('risk.max_single_position_fraction', 0.03))
    daily_loss_limit_fraction: float = float(_cfg('risk.daily_loss_limit_fraction', 0.03))
    drawdown_trigger_fraction: float = float(_cfg('risk.drawdown_trigger_fraction', 0.05))
    min_signal_confidence: float = float(_cfg('risk.min_signal_confidence', 0.65))
    max_slippage_fraction: float = float(_cfg('risk.max_slippage_fraction', 0.005))
    api_error_kill_threshold: int = int(_cfg('risk.api_error_kill_threshold', 10))
    failed_order_kill_threshold: int = int(_cfg('risk.failed_order_kill_threshold', 5))

    postgres_dsn: str = _cfg('storage.postgres_dsn', 'postgresql+asyncpg://postgres:postgres@postgres:5432/cryptorisk')
    redis_url: str = _cfg('storage.redis_url', 'redis://redis:6379/0')
    timescaledb_enabled: bool = bool(_cfg('storage.timescaledb_enabled', True))
    retention_days: int = int(_cfg('storage.retention_days', 30))

    exchange_names_csv: str = _cfg('exchanges.names', 'binance,bitget,btcc')

    binance_api_key: str | None = None
    binance_api_secret: str | None = None
    binance_sandbox: bool = bool(_cfg('exchanges.binance.sandbox', True))
    binance_testnet_rest_url: str | None = _cfg('exchanges.binance.testnet_rest_url', None)
    binance_ws_url: str | None = _cfg('exchanges.binance.ws_url', 'wss://stream.binance.com:9443/ws')

    bitget_api_key: str | None = None
    bitget_api_secret: str | None = None
    bitget_passphrase: str | None = None
    bitget_sandbox: bool = bool(_cfg('exchanges.bitget.sandbox', True))
    bitget_testnet_rest_url: str | None = _cfg('exchanges.bitget.testnet_rest_url', None)
    bitget_ws_url: str | None = _cfg('exchanges.bitget.ws_url', 'wss://ws.bitget.com/v2/ws/public')

    btcc_api_key: str | None = None
    btcc_api_secret: str | None = None
    btcc_sandbox: bool = bool(_cfg('exchanges.btcc.sandbox', True))
    btcc_testnet_rest_url: str | None = _cfg('exchanges.btcc.testnet_rest_url', None)
    btcc_ws_url: str | None = _cfg('exchanges.btcc.ws_url', None)

    @property
    def cors_origin_list(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(',') if item.strip()]

    @property
    def exchange_names(self) -> list[str]:
        return [item.strip() for item in self.exchange_names_csv.split(',') if item.strip()]


settings = Settings()

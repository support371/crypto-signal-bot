from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_iso() -> str:
    return utc_now().isoformat()


@dataclass
class RuntimePosition:
    exchange: str
    symbol: str
    side: str
    size_usdt: float
    entry_price: float
    current_price: float
    quantity: float = 0.0
    status: str = 'open'
    order_id: str | None = None
    exit_order_id: str | None = None
    id: str = field(default_factory=lambda: str(uuid4()))
    opened_at: str = field(default_factory=utc_iso)
    closed_at: str | None = None

    @property
    def unrealized_pnl(self) -> float:
        direction = 1 if self.side == 'buy' else -1
        return round(((self.current_price - self.entry_price) / self.entry_price) * self.size_usdt * direction, 2)


@dataclass
class RuntimeState:
    prices: dict[str, float] = field(default_factory=dict)
    balances: dict[str, float] = field(default_factory=dict)
    positions: list[RuntimePosition] = field(default_factory=list)
    realized_pnl_by_exchange: dict[str, float] = field(default_factory=dict)
    last_signal: dict[str, Any] | None = None
    last_guardian_reason: str | None = None
    last_guardian_heartbeat_at: str = field(default_factory=utc_iso)
    kill_switch_active: bool = False
    halted: bool = False
    api_error_count: int = 0
    failed_order_count: int = 0
    audit: list[dict[str, Any]] = field(default_factory=list)
    equity_high_water_mark: float = 0.0
    current_total_capital: float = 0.0
    started_at: str = field(default_factory=utc_iso)
    exchange_connectivity: dict[str, bool] = field(default_factory=dict)
    exchange_messages: dict[str, str] = field(default_factory=dict)
    exchange_streaming: dict[str, bool] = field(default_factory=dict)
    exchange_last_tick_at: dict[str, str | None] = field(default_factory=dict)
    last_reconciliation: dict[str, Any] = field(default_factory=dict)

    def bootstrap(self, exchanges: list[str], initial_capital: float) -> None:
        split = round(initial_capital / max(len(exchanges), 1), 2)
        self.balances = {exchange: split for exchange in exchanges}
        self.realized_pnl_by_exchange = {exchange: 0.0 for exchange in exchanges}
        seed_prices = {
            'binance': 95000.0,
            'bitget': 94990.0,
            'btcc': 95010.0,
        }
        self.prices = {exchange: seed_prices.get(exchange, 95000.0) for exchange in exchanges}
        self.exchange_connectivity = {exchange: False for exchange in exchanges}
        self.exchange_messages = {exchange: 'not connected' for exchange in exchanges}
        self.exchange_streaming = {exchange: False for exchange in exchanges}
        self.exchange_last_tick_at = {exchange: None for exchange in exchanges}
        self.current_total_capital = initial_capital
        self.equity_high_water_mark = initial_capital

from __future__ import annotations

from collections import defaultdict, deque
from time import time

from fastapi import HTTPException, Request

from app.config import settings


class InMemoryRateLimiter:
    def __init__(self, max_requests: int, window_seconds: int = 60) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str) -> None:
        now = time()
        queue = self._hits[key]
        while queue and (now - queue[0]) > self.window_seconds:
            queue.popleft()
        if len(queue) >= self.max_requests:
            raise HTTPException(status_code=429, detail='Rate limit exceeded')
        queue.append(now)


limiter = InMemoryRateLimiter(settings.read_rate_limit_per_minute)


def rate_limit_dependency(request: Request) -> None:
    client = request.client.host if request.client else 'anonymous'
    limiter.check(client)

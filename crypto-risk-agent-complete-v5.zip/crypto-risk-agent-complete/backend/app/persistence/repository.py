from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.persistence.models import AuditEvent, MetricSnapshot, OrderRecord, ReconciliationSnapshot


class Repository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add_audit_event(self, event: dict) -> None:
        self.session.add(
            AuditEvent(
                id=event['id'],
                kind=event['kind'],
                message=event['message'],
                payload=event['payload'],
                timestamp=datetime.fromisoformat(event['timestamp']),
            )
        )
        await self.session.commit()

    async def upsert_order(self, order: dict) -> None:
        existing = await self.session.get(OrderRecord, order['id'])
        if existing:
            existing.current_price = order['current_price']
            existing.unrealized_pnl = order['unrealized_pnl']
            existing.status = order['status']
            existing.closed_at = datetime.fromisoformat(order['closed_at']) if order.get('closed_at') else None
        else:
            self.session.add(
                OrderRecord(
                    id=order['id'],
                    exchange=order['exchange'],
                    symbol=order['symbol'],
                    side=order['side'],
                    size_usdt=order['size_usdt'],
                    entry_price=order['entry_price'],
                    current_price=order['current_price'],
                    unrealized_pnl=order['unrealized_pnl'],
                    status=order['status'],
                    opened_at=datetime.fromisoformat(order['opened_at']),
                    closed_at=datetime.fromisoformat(order['closed_at']) if order.get('closed_at') else None,
                )
            )
        await self.session.commit()

    async def add_metric_snapshot(self, *, total_capital: float, realized_pnl: float, unrealized_pnl: float, daily_pnl: float) -> None:
        self.session.add(
            MetricSnapshot(
                total_capital=total_capital,
                realized_pnl=realized_pnl,
                unrealized_pnl=unrealized_pnl,
                daily_pnl=daily_pnl,
                timestamp=datetime.now(timezone.utc),
            )
        )
        await self.session.commit()

    async def recent_audit(self, limit: int = 250) -> list[dict]:
        result = await self.session.execute(select(AuditEvent).order_by(desc(AuditEvent.timestamp)).limit(limit))
        rows = result.scalars().all()
        return [
            {
                'id': row.id,
                'kind': row.kind,
                'message': row.message,
                'payload': row.payload,
                'timestamp': row.timestamp.isoformat(),
            }
            for row in rows
        ]

    async def orders(self) -> list[dict]:
        result = await self.session.execute(select(OrderRecord).order_by(desc(OrderRecord.opened_at)))
        rows = result.scalars().all()
        return [
            {
                'id': row.id,
                'exchange': row.exchange,
                'symbol': row.symbol,
                'side': row.side,
                'size_usdt': row.size_usdt,
                'entry_price': row.entry_price,
                'current_price': row.current_price,
                'unrealized_pnl': row.unrealized_pnl,
                'status': row.status,
                'opened_at': row.opened_at.isoformat(),
                'closed_at': row.closed_at.isoformat() if row.closed_at else None,
            }
            for row in rows
        ]

    async def add_reconciliation_snapshot(
        self,
        *,
        exchange: str,
        runtime_balance: float,
        exchange_balance: float,
        drift_usdt: float,
        runtime_open_positions: int,
        exchange_open_orders: int,
        status: str,
        details: dict,
    ) -> None:
        self.session.add(
            ReconciliationSnapshot(
                exchange=exchange,
                runtime_balance=runtime_balance,
                exchange_balance=exchange_balance,
                drift_usdt=drift_usdt,
                runtime_open_positions=runtime_open_positions,
                exchange_open_orders=exchange_open_orders,
                status=status,
                details=details,
                timestamp=datetime.now(timezone.utc),
            )
        )
        await self.session.commit()

    async def recent_reconciliation(self, limit: int = 100) -> list[dict]:
        result = await self.session.execute(
            select(ReconciliationSnapshot).order_by(desc(ReconciliationSnapshot.timestamp)).limit(limit)
        )
        rows = result.scalars().all()
        return [
            {
                'id': row.id,
                'exchange': row.exchange,
                'runtime_balance': row.runtime_balance,
                'exchange_balance': row.exchange_balance,
                'drift_usdt': row.drift_usdt,
                'runtime_open_positions': row.runtime_open_positions,
                'exchange_open_orders': row.exchange_open_orders,
                'status': row.status,
                'details': row.details,
                'timestamp': row.timestamp.isoformat(),
            }
            for row in rows
        ]

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from app.config import settings


async def bootstrap_timescaledb(engine: AsyncEngine) -> None:
    if not settings.timescaledb_enabled:
        return
    statements = [
        "CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;",
        "SELECT create_hypertable('metric_snapshots', 'timestamp', if_not_exists => TRUE, migrate_data => TRUE);",
        "SELECT create_hypertable('reconciliation_snapshots', 'timestamp', if_not_exists => TRUE, migrate_data => TRUE);",
        f"SELECT add_retention_policy('metric_snapshots', INTERVAL '{settings.retention_days} days', if_not_exists => TRUE);",
        f"SELECT add_retention_policy('reconciliation_snapshots', INTERVAL '{settings.retention_days} days', if_not_exists => TRUE);",
    ]
    async with engine.begin() as conn:
        for stmt in statements:
            try:
                await conn.execute(text(stmt))
            except Exception:
                # The platform may not have TimescaleDB installed. Fail open.
                break

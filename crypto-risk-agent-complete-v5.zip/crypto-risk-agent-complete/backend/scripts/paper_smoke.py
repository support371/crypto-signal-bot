from __future__ import annotations

import asyncio
import json

from app.config import settings
from app.services.engine import TradingEngine
from app.state import RuntimeState
from app.ws import ConnectionManager


async def main() -> int:
    state = RuntimeState()
    state.bootstrap(settings.exchange_names, settings.total_capital)
    engine = TradingEngine(state, ConnectionManager())
    await engine.initialize()
    try:
        for _ in range(3):
            await engine.tick()
        print(json.dumps({
            'status': 'ok',
            'signal': state.last_signal,
            'balances': state.balances,
            'positions': len(state.positions),
            'halted': state.halted,
        }, indent=2))
        return 0
    finally:
        await engine.market.close()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))

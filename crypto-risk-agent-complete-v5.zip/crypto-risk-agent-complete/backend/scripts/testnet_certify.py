from __future__ import annotations

import argparse
import asyncio
import json
from typing import Any

from app.adapters.live import LiveCcxtAdapter
from app.config import settings
from app.state import RuntimeState


async def _capture_stream_tick(adapter: LiveCcxtAdapter, symbol: str, timeout_seconds: int = 10) -> dict[str, Any]:
    event = asyncio.Event()
    payload: dict[str, Any] = {'received': False, 'price': None}

    async def on_price(_exchange: str, price: float) -> None:
        payload['received'] = True
        payload['price'] = price
        event.set()

    started = await adapter.start_ticker_stream(symbol, on_price)
    if not started:
        return {'supported': False, 'received': False, 'price': None}
    try:
        await asyncio.wait_for(event.wait(), timeout=timeout_seconds)
    except asyncio.TimeoutError:
        pass
    finally:
        await adapter.stop_ticker_stream()
    payload['supported'] = True
    return payload


async def certify_exchange(adapter: LiveCcxtAdapter, symbol: str, order_amount: float, place_orders: bool) -> dict[str, Any]:
    report: dict[str, Any] = {
        'exchange': adapter.name,
        'connected': False,
        'ticker': None,
        'balance': None,
        'health': None,
        'stream': None,
        'order_roundtrip': None,
        'errors': [],
    }
    try:
        await adapter.connect()
        report['connected'] = True
        report['ticker'] = await adapter.fetch_ticker(symbol)
        report['balance'] = await adapter.fetch_balance()
        ok, message = await adapter.health()
        report['health'] = {'ok': ok, 'message': message}
        report['stream'] = await _capture_stream_tick(adapter, symbol)

        if place_orders:
            order = await adapter.create_market_order(symbol, 'buy', order_amount)
            order_id = str(order.get('id'))
            fetched = await adapter.fetch_order(order_id, symbol)
            report['order_roundtrip'] = {
                'created_order_id': order_id,
                'fetched_status': fetched.get('status'),
                'filled': fetched.get('filled'),
                'average': fetched.get('average') or fetched.get('price'),
            }
        return report
    except Exception as exc:
        report['errors'].append(str(exc))
        return report
    finally:
        try:
            await adapter.close()
        except Exception:
            pass


async def main() -> int:
    parser = argparse.ArgumentParser(description='Exchange testnet certification flow')
    parser.add_argument('--symbol', default=settings.symbol)
    parser.add_argument('--order-amount', type=float, default=settings.certification_order_amount)
    parser.add_argument('--place-orders', action='store_true')
    args = parser.parse_args()

    state = RuntimeState()
    state.bootstrap(settings.exchange_names, settings.total_capital)
    adapters = [LiveCcxtAdapter(name, state) for name in settings.exchange_names]
    reports = []
    for adapter in adapters:
        reports.append(await certify_exchange(adapter, args.symbol, args.order_amount, args.place_orders))

    print(json.dumps({'symbol': args.symbol, 'reports': reports}, indent=2))
    failures = [
        r for r in reports
        if r['errors'] or not r['connected'] or not (r.get('health') or {}).get('ok', False)
    ]
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))

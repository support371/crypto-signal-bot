from app.rate_limit import InMemoryRateLimiter


def test_rate_limiter_allows_then_blocks():
    limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)
    limiter.check('client')
    limiter.check('client')
    blocked = False
    try:
        limiter.check('client')
    except Exception:
        blocked = True
    assert blocked is True

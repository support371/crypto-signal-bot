from fastapi.testclient import TestClient

from app.main import app


def test_reconciliation_endpoint_exists():
    client = TestClient(app)
    response = client.get('/reconciliation/status')
    assert response.status_code == 200
    data = response.json()
    assert 'latest_runtime' in data
    assert 'history' in data

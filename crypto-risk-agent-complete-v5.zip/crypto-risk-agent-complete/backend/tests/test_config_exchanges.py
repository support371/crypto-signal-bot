from app.config import settings


def test_exchange_names_loaded() -> None:
    assert 'binance' in settings.exchange_names

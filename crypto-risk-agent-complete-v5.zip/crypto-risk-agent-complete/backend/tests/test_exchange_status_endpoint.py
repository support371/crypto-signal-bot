from fastapi.testclient import TestClient
from app.main import app


def test_exchange_status_endpoint() -> None:
    client = TestClient(app)
    response = client.get('/exchange/status')
    assert response.status_code == 200
    body = response.json()
    assert isinstance(body, dict)

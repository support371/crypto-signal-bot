from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_kill_switch_requires_auth():
    response = client.post('/kill-switch', json={'active': True, 'reason': 'test'})
    assert response.status_code == 401

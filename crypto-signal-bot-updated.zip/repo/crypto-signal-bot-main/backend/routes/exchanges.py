"""
Exchanges API.

Provides metadata about supported exchange adapters and their capabilities.
"""
from __future__ import annotations

from fastapi import APIRouter

from backend.logic.exchange_adapter import SUPPORTED_EXCHANGES

exchanges_router = APIRouter(prefix="/api/v1/exchanges", tags=["exchanges"])


@exchanges_router.get("/", summary="List supported exchanges", response_model=dict)
def list_supported_exchanges() -> dict:
    """
    Return a list of supported exchanges and their basic capabilities.

    The capabilities are static placeholders and can be refined as adapter
    implementations evolve.
    """
    exchanges = []
    for exchange in sorted(SUPPORTED_EXCHANGES):
        # Define simple capability flags; adjust as adapters mature
        capabilities = {
            "spot": True,
            "testnet": True,
            # BTCC is missing full testnet/live parity, so mark live=False
            "live": exchange != "btcc",
        }
        exchanges.append({"id": exchange, **capabilities})
    return {"exchanges": exchanges}
#!/bin/bash
# ================================================================
# DEFINITIVE CLEAN RESET SCRIPT
# Consolidates all branches into one clean main branch
# Run from INSIDE the cloned repo directory
# ================================================================
set -e

echo ""
echo "=== crypto-signal-bot: Clean Branch Consolidation ==="
echo ""

# Safety check
if [ ! -f "package.json" ]; then
  echo "ERROR: Run this from inside the crypto-signal-bot repo"
  exit 1
fi

# 1. Fetch everything from all branches
echo "1. Fetching all branches..."
git fetch --all --prune

# 2. Hard-reset to last known-good Vercel build (2c41b99)
#    This is the commit "Fix Vercel ignore rule for nested Supabase files"
#    which was the last READY production deployment
echo "2. Resetting to last clean base (2c41b99)..."
git checkout main
git reset --hard 2c41b99c28f2ac1a852326cde5a74a8c7ec1a589

# 3. Apply the complete migration zip over the top
echo "3. Applying complete migration files..."
ZIPFILE="$(dirname "$0")/../complete_push_all_phases.zip"
if [ ! -f "$ZIPFILE" ]; then
  echo "   Zip not found at $ZIPFILE — extracting from current dir..."
  ZIPFILE="./complete_push_all_phases.zip"
fi

if [ -f "$ZIPFILE" ]; then
  unzip -o "$ZIPFILE" -d .
  echo "   Migration files applied."
else
  echo "   WARNING: Zip file not found. Files already applied from previous steps."
fi

# 4. Stage and commit everything
echo "4. Committing all changes..."
git add -A
git status --short | head -20
git commit -m "feat: complete backend-first migration + vercel config (clean reset from 2c41b99)"

# 5. Force push to main (replaces the broken commit history)
echo "5. Force-pushing to main..."
git push origin main --force

echo ""
echo "=== DONE ==="
echo "Vercel will auto-deploy in ~30 seconds."
echo "Expected result: READY (same build as 2c41b99 + all migration files)"

# backend/main.py
"""
FastAPI application entry point.

Wires together all routes and services from phases 6–15 + MT5.
This is the file uvicorn/gunicorn point to.

Start commands:
  Dev:  uvicorn backend.main:app --reload --port 8000
  Prod: gunicorn backend.main:app -k uvicorn.workers.UvicornWorker -w 4 --bind 0.0.0.0:8000
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# ── Config ───────────────────────────────────────────────────────────────────
from backend.config.loader import (
    get_settings,
    get_exchange_config,
)

# ── Routes ───────────────────────────────────────────────────────────────────
from backend.routes.price       import router as price_router
from backend.routes.signal      import router as signal_router
from backend.routes.intent      import router as intent_router
from backend.routes.kill_switch import router as kill_switch_router
from backend.routes.broker      import router as broker_router
from backend.routes.broker      import mt5_router

# ── Services ─────────────────────────────────────────────────────────────────
from backend.services.market_data.stream      import start_stream,        stop_stream
from backend.services.prediction_bot.service  import start_prediction_loop, stop_prediction_loop
from backend.services.guardian_bot.service    import start_guardian,       stop_guardian
from backend.services.reconciliation.service  import start_reconciliation, stop_reconciliation

# ── Persistence ──────────────────────────────────────────────────────────────
from backend.db.session import init_db, close_db

log = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)


# ---------------------------------------------------------------------------
# Lifespan — startup / shutdown
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Startup order (matches DEPLOYMENT.md):
      1. PostgreSQL / SQLite — tables created
      2. FastAPI app starts (health route available)
      3. Market data stream starts
      4. Prediction loop starts
      5. Guardian loop starts
      6. Reconciliation loop starts
    """
    log.info("=== crypto-signal-bot backend starting ===")

    # 1. Database
    try:
        await init_db()
        log.info("[startup] Database ready.")
    except Exception as exc:
        log.error("[startup] Database init failed: %s", exc)
        raise

    # 3. Market data stream
    try:
        await start_stream()
        log.info("[startup] Market data stream started.")
    except Exception as exc:
        log.warning("[startup] Market data stream failed to start: %s", exc)

    # 4. Prediction loop
    try:
        await start_prediction_loop()
        log.info("[startup] Prediction loop started.")
    except Exception as exc:
        log.warning("[startup] Prediction loop failed to start: %s", exc)

    # 5. Guardian
    try:
        await start_guardian()
        log.info("[startup] Guardian started.")
    except Exception as exc:
        log.warning("[startup] Guardian failed to start: %s", exc)

    # 6. Reconciliation
    try:
        await start_reconciliation()
        log.info("[startup] Reconciliation loop started.")
    except Exception as exc:
        log.warning("[startup] Reconciliation loop failed to start: %s", exc)

    log.info("=== Backend ready ===")
    yield

    # Shutdown
    log.info("=== crypto-signal-bot backend shutting down ===")
    await stop_reconciliation()
    await stop_guardian()
    await stop_prediction_loop()
    await stop_stream()
    await close_db()
    log.info("=== Shutdown complete ===")


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="crypto-signal-bot Backend",
        description="Backend-first trading signal and execution API.",
        version="2.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # CORS
    from backend.middleware.auth import get_cors_config
    app.add_middleware(CORSMiddleware, **get_cors_config())

    # ── Routes ───────────────────────────────────────────────────────────────
    app.include_router(price_router)
    app.include_router(signal_router)
    app.include_router(intent_router)
    app.include_router(kill_switch_router)
    app.include_router(broker_router)
    app.include_router(mt5_router)

    # ── Health ───────────────────────────────────────────────────────────────
    @app.get("/health", tags=["system"])
    async def health():
        from backend.services.guardian_bot.service import is_kill_switch_active
        cfg = get_exchange_config()
        active = await is_kill_switch_active()
        return {
            "status":              "ok",
            "mode":                cfg.mode,
            "kill_switch_active":  active,
            "kill_switch_reason":  None,
            "ts":                  int(time.time()),
        }

    # ── Config (public read) ─────────────────────────────────────────────────
    @app.get("/config", tags=["system"])
    async def get_config():
        cfg = get_exchange_config()
        auth = get_settings()
        return {
            "mode":         cfg.mode,
            "auth_enabled": bool(getattr(auth, "backend_api_key", None)),
            "exchanges":    ["btcc", "binance", "bitget"],
        }

    # ── Balance (delegated to exchange adapter) ───────────────────────────────
    @app.get("/balance", tags=["portfolio"])
    async def get_balance():
        from backend.engine.pnl import get_usdt_balance, get_all_lots
        from backend.config.loader import get_exchange_config as _cfg
        mode = _cfg().mode
        balance = float(get_usdt_balance())
        lots    = get_all_lots()
        positions = {sym: sum(float(l.quantity) for l in ls) for sym, ls in lots.items() if ls}
        return {"balances": {"USDT": balance, **positions}, "positions": [], "mode": mode}

    # ── Orders (recent filled orders) ────────────────────────────────────────
    @app.get("/orders", tags=["portfolio"])
    async def get_orders():
        from backend.engine.pnl import get_realized_trades
        trades = get_realized_trades()
        orders = [
            {
                "id":         t.order_id,
                "symbol":     t.symbol,
                "side":       t.side,
                "quantity":   float(t.quantity),
                "fill_price": float(t.close_price),
                "status":     "FILLED",
                "created_at": t.closed_at,
            }
            for t in reversed(trades[-50:])
        ]
        return {"orders": orders}

    # ── Earnings ─────────────────────────────────────────────────────────────
    @app.get("/earnings/summary", tags=["earnings"])
    async def earnings_summary():
        from backend.engine.pnl import get_pnl_summary
        s = await get_pnl_summary()
        return {
            "total_realized_pnl": float(s.total_realized_pnl),
            "trade_count":        s.trade_count,
            "win_rate_pct":       s.win_rate_pct,
            "open_lots":          s.open_lots,
            "best_trade_pnl":     float(s.best_trade_pnl),
            "worst_trade_pnl":    float(s.worst_trade_pnl),
            "avg_pnl_per_trade":  float(s.avg_pnl_per_trade),
        }

    @app.get("/earnings/history", tags=["earnings"])
    async def earnings_history(limit: int = 20):
        from backend.engine.pnl import get_realized_trades
        trades = get_realized_trades()[-limit:]
        return {
            "trades": [
                {
                    "symbol":       t.symbol,
                    "side":         t.side,
                    "quantity":     float(t.quantity),
                    "open_price":   float(t.open_price),
                    "close_price":  float(t.close_price),
                    "realized_pnl": float(t.realized_pnl),
                    "pnl_pct":      t.pnl_pct,
                    "closed_at":    t.closed_at,
                    "order_id":     t.order_id,
                }
                for t in reversed(trades)
            ]
        }

    @app.post("/earnings/reset", tags=["earnings"])
    async def earnings_reset():
        from backend.engine.pnl import reset_pnl_state
        from decimal import Decimal
        reset_pnl_state(starting_balance=Decimal("10000"))
        return {"status": "reset", "starting_balance": 10000}

    # ── Audit ─────────────────────────────────────────────────────────────────
    @app.get("/audit", tags=["audit"])
    async def get_audit():
        from backend.services.audit.service import get_recent_entries
        from backend.engine.pnl import get_realized_trades
        trades = get_realized_trades()
        entries = get_recent_entries(100)
        return {
            "intents":    [],
            "orders":     [
                {"id": t.order_id, "symbol": t.symbol, "side": t.side,
                 "status": "FILLED", "fill_price": float(t.close_price),
                 "updated_at": t.closed_at, "created_at": t.closed_at}
                for t in reversed(trades[-20:])
            ],
            "withdrawals": [],
            "risk_events": [
                {"intent_id": None, "reason": e.reason,
                 "risk_score": None, "timestamp": e.timestamp}
                for e in entries
                if e.event_type in ("risk_gate_denied", "kill_switch_manual", "kill_switch_guardian")
            ],
        }

    # ── Market state (POST) ───────────────────────────────────────────────────
    @app.post("/market-state", tags=["signals"])
    async def post_market_state(body: dict):
        symbol = body.get("symbol", "BTCUSDT")
        from backend.services.prediction_bot.service import get_latest_signal
        sig = await get_latest_signal(symbol)
        return {
            "signal":        {
                "direction":  sig.direction,
                "confidence": sig.confidence,
                "regime":     sig.regime,
                "horizon":    sig.horizon,
            },
            "risk":          {
                "score":         50,
                "decision":      "HOLD",
                "approved":      False,
                "positionSize":  0.0,
                "reasoning":     "Risk engine not fully wired.",
            },
            "microstructure": None,
        }

    # ── Withdraw ─────────────────────────────────────────────────────────────
    @app.post("/withdraw", tags=["portfolio"])
    async def post_withdraw(body: dict):
        from backend.services.audit.service import append, AuditEventType
        await append(
            event_type=AuditEventType.WITHDRAWAL,
            actor="operator",
            symbol=body.get("asset"),
            quantity=body.get("amount"),
            reason=f"Withdraw to {body.get('address')}",
        )
        return {"status": "recorded", "asset": body.get("asset"), "amount": body.get("amount")}

    # ── Metrics (Prometheus-style text) ──────────────────────────────────────
    @app.get("/metrics", tags=["system"])
    async def get_metrics():
        from backend.engine.pnl import get_pnl_summary, get_realized_trades
        s = await get_pnl_summary()
        trades = get_realized_trades()
        buys  = sum(1 for t in trades if t.side == "BUY")
        sells = sum(1 for t in trades if t.side == "SELL")
        lines = [
            f'orders_total{{side="BUY"}} {buys}',
            f'orders_total{{side="SELL"}} {sells}',
            f"risk_blocks_total 0",
            f"kill_switch_triggers 0",
            f"api_errors_total 0",
            f"pnl_realized {float(s.total_realized_pnl):.4f}",
            f"pnl_unrealized {float(s.total_unrealized_pnl):.4f}",
        ]
        from fastapi.responses import PlainTextResponse
        return PlainTextResponse("\n".join(lines) + "\n")

    return app


app = create_app()

# backend/config/loader.py
"""
Config loader — single source of runtime configuration.

Reads from environment variables (and .env file in dev).
All subsystems call get_*_config() functions here — never os.environ directly.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


# ---------------------------------------------------------------------------
# Dot-env support (dev only — production uses real env vars)
# ---------------------------------------------------------------------------

def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv(override=False)
    except ImportError:
        pass  # python-dotenv not installed — use real env vars

_load_dotenv()


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()

def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(os.environ.get(key, default))
    except (ValueError, TypeError):
        return default

def _env_bool(key: str, default: bool = False) -> bool:
    val = os.environ.get(key, "").lower()
    if val in ("1", "true", "yes"):
        return True
    if val in ("0", "false", "no"):
        return False
    return default


# ---------------------------------------------------------------------------
# Config dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ExchangeConfig:
    mode:             str            # "paper" | "live"
    btcc_api_key:     Optional[str]
    btcc_api_secret:  Optional[str]
    btcc_base_url:    str
    binance_api_key:  Optional[str]
    binance_api_secret: Optional[str]
    binance_base_url: str
    binance_testnet:  bool
    bitget_api_key:   Optional[str]
    bitget_api_secret: Optional[str]
    bitget_passphrase: Optional[str]
    bitget_base_url:  str


@dataclass
class RiskConfig:
    risk_tolerance:           float
    position_size_fraction:   float
    spread_stress_threshold:  float
    volatility_sensitivity:   float
    max_drawdown_pct:         float
    max_api_errors:           int
    max_failed_orders:        int


@dataclass
class RedisConfig:
    url:                  str
    price_ttl_seconds:    int
    signal_ttl_seconds:   int


@dataclass
class DatabaseConfig:
    url:          str
    echo:         bool
    pool_size:    int
    max_overflow: int


@dataclass
class AuthConfig:
    api_key:      Optional[str]
    auth_enabled: bool


@dataclass
class Settings:
    database_url:           str
    redis_url:              str
    exchange_mode:          str
    cors_allowed_origins:   list[str]
    backend_api_key:        Optional[str]
    debug:                  bool


# ---------------------------------------------------------------------------
# Factories
# ---------------------------------------------------------------------------

def get_settings() -> Settings:
    return Settings(
        database_url=_env("DATABASE_URL", "sqlite+aiosqlite:///./dev.db"),
        redis_url=_env("REDIS_URL", "redis://localhost:6379/0"),
        exchange_mode=_env("EXCHANGE_MODE", "paper"),
        cors_allowed_origins=[
            o.strip()
            for o in _env("CORS_ALLOWED_ORIGINS", "*").split(",")
            if o.strip()
        ],
        backend_api_key=_env("BACKEND_API_KEY") or None,
        debug=_env_bool("DEBUG", False),
    )


def get_exchange_config() -> ExchangeConfig:
    return ExchangeConfig(
        mode=_env("EXCHANGE_MODE", "paper"),
        btcc_api_key=_env("BTCC_API_KEY") or None,
        btcc_api_secret=_env("BTCC_API_SECRET") or None,
        btcc_base_url=_env("BTCC_BASE_URL", "https://api.btcc.com"),
        binance_api_key=_env("BINANCE_API_KEY") or None,
        binance_api_secret=_env("BINANCE_API_SECRET") or None,
        binance_base_url=_env("BINANCE_BASE_URL", "https://api.binance.com"),
        binance_testnet=_env_bool("BINANCE_TESTNET", True),
        bitget_api_key=_env("BITGET_API_KEY") or None,
        bitget_api_secret=_env("BITGET_API_SECRET") or None,
        bitget_passphrase=_env("BITGET_PASSPHRASE") or None,
        bitget_base_url=_env("BITGET_BASE_URL", "https://api.bitget.com"),
    )


def get_risk_config() -> RiskConfig:
    return RiskConfig(
        risk_tolerance=float(_env("RISK_TOLERANCE", "0.5")),
        position_size_fraction=float(_env("POSITION_SIZE_FRACTION", "0.1")),
        spread_stress_threshold=float(_env("SPREAD_STRESS_THRESHOLD", "0.002")),
        volatility_sensitivity=float(_env("VOLATILITY_SENSITIVITY", "0.5")),
        max_drawdown_pct=float(_env("MAX_DRAWDOWN_PCT", "5.0")),
        max_api_errors=_env_int("MAX_API_ERRORS", 10),
        max_failed_orders=_env_int("MAX_FAILED_ORDERS", 5),
    )


def get_redis_config() -> RedisConfig:
    return RedisConfig(
        url=_env("REDIS_URL", "redis://localhost:6379/0"),
        price_ttl_seconds=_env_int("PRICE_TTL_SECONDS", 60),
        signal_ttl_seconds=_env_int("SIGNAL_TTL_SECONDS", 120),
    )


def get_database_config() -> DatabaseConfig:
    url = _env("DATABASE_URL", "sqlite+aiosqlite:///./dev.db")
    return DatabaseConfig(
        url=url,
        echo=_env_bool("DATABASE_ECHO", False),
        pool_size=_env_int("DATABASE_POOL_SIZE", 5),
        max_overflow=_env_int("DATABASE_MAX_OVERFLOW", 10),
    )


def get_auth_config() -> AuthConfig:
    key = _env("BACKEND_API_KEY") or None
    return AuthConfig(
        api_key=key,
        auth_enabled=bool(key),
    )
